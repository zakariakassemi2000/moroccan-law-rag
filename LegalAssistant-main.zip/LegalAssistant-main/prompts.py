context = """Purpose: The primary role of this agent is to assist users by analyzing laws documents. It should
            be able to answer  questions about Laws in Morocco. """

